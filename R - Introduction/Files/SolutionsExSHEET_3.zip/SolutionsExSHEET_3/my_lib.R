#############################################################################
## "my_lib.R
## contains some functions for Exercice sheet 3.
#############################################################################

## gives back absolute values of x:
abs_val = function(x){ return(abs(x)) }

## returns sign flipped x:
neg_val = function(x){ return(-x) }

## returns x, except for elements of value == 1
all_except_1 = function(x){ return( x[x!=1] ) }

