##############################################################################
## Task 1 ##
##############################################################################

source("my_lib.R")

ls() # what is in my workspace?

x = c(-1,1,2,3,-4,-3,2,0.5,0)

abs_val(x)
neg_val(x)
all_except_1(x)


##############################################################################
## Task 2 ##
##############################################################################

  data = read.delim("../Data_3/tomatoes.csv",sep=";",dec=".",header=TRUE)
  str(data) # color should be a factor:
  data$color = as.factor(data$color)
  str(data)

# a)
  choice = data[data$temperature > 42,]
  choice

# b)
  sum( data$water=="wet" )
  # or (more complicated): 
  length(data$water[data$water=="wet"])
  # or (see also later):
  table(data$water)

# c)
  selection = data$water=="humid" & data$fertilizer=="middle" & (data$color==2 | data$color==3)
  sum(selection)

